  	$("#typed").typed({
  		strings: ["Hello world.", "Hii Arvind."],
  		typeSpeed: 200,
  		startDelay: 0,
  		backSpeed: 60,
  		backDelay: 1000,
  		loop: true,
  		cursorChar: "..>",
  		contentType: 'html'
  	});