$('#responsiveTabsDemo').responsiveTabs({
    startCollapsed: 'accordion'
});